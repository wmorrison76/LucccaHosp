/**
 * PATCH v1 - CD-05: Enhanced Export & Print Model
 * Changes:
 * - Added .glb and .obj export formats.
 */
import * as THREE from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { OBJExporter } from 'three/examples/jsm/exporters/OBJExporter.js';

export function exportModel(scene, format = 'gltf') {
  if (format === 'gltf' || format === 'glb') {
    const exporter = new GLTFExporter();
    exporter.parse(scene, (result) => {
      const output = format === 'glb' ? result : JSON.stringify(result);
      const blob = new Blob([output], { type: 'application/octet-stream' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `cake_model.${format}`;
      link.click();
    });
  } else if (format === 'obj') {
    const exporter = new OBJExporter();
    const result = exporter.parse(scene);
    const blob = new Blob([result], { type: 'text/plain' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'cake_model.obj';
    link.click();
  }
}
