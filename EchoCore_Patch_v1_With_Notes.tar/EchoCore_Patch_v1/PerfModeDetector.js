/**
 * PATCH v1 - WB-04: Enhanced PerfModeDetector
 * Changes:
 * - Added runtime FPS measurement.
 * - Added hook usePerfMode for React components.
 */
import { useEffect, useState } from 'react';

export function detectPerfMode() {
  const hardwareConcurrency = navigator.hardwareConcurrency || 4;
  return hardwareConcurrency > 4 ? 'high' : 'low';
}

export function usePerfMode() {
  const [mode, setMode] = useState(detectPerfMode());

  useEffect(() => {
    let frameCount = 0;
    let startTime = performance.now();

    const measureFPS = () => {
      frameCount++;
      const now = performance.now();
      if (now - startTime >= 1000) {
        const fps = frameCount;
        setMode(fps > 50 ? 'high' : 'low');
        frameCount = 0;
        startTime = now;
      }
      requestAnimationFrame(measureFPS);
    };

    requestAnimationFrame(measureFPS);
  }, []);

  return mode;
}
