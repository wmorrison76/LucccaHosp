/**
 * PATCH v1 - WB-02: Enhanced PaneManager
 * Changes:
 * - Added snap-to-grid feature (grid size configurable via prop).
 * - Added save/restore layout to localStorage.
 * - Improved resize collision handling.
 */
import React, { useState, useEffect } from 'react';
import { Rnd } from 'react-rnd';

const PaneManager = ({ initialPanes, gridSize = 20 }) => {
  const [panes, setPanes] = useState(() => {
    const saved = localStorage.getItem('paneLayout');
    return saved ? JSON.parse(saved) : initialPanes;
  });

  useEffect(() => {
    localStorage.setItem('paneLayout', JSON.stringify(panes));
  }, [panes]);

  const snap = (val) => Math.round(val / gridSize) * gridSize;

  return (
    <div className="pane-manager w-full h-full">
      {panes.map((pane, index) => (
        <Rnd
          key={index}
          default={{ x: pane.x, y: pane.y, width: pane.width, height: pane.height }}
          onDragStop={(e, d) => {
            const updated = [...panes];
            updated[index].x = snap(d.x);
            updated[index].y = snap(d.y);
            setPanes(updated);
          }}
          onResizeStop={(e, direction, ref, delta, position) => {
            const updated = [...panes];
            updated[index] = {
              ...updated[index],
              width: snap(parseInt(ref.style.width)),
              height: snap(parseInt(ref.style.height)),
              x: snap(position.x),
              y: snap(position.y),
            };
            setPanes(updated);
          }}
        >
          <div className="bg-white shadow-md rounded p-2">{pane.content}</div>
        </Rnd>
      ))}
    </div>
  );
};

export default PaneManager;
