/**
 * LUCCCA | CD-01
 * Central repository for cake textures.
 */
export const TextureLibrary = {
  smooth: '/textures/smooth.jpg',
  creamy: '/textures/creamy.jpg',
  shiny: '/textures/shiny.jpg',
  grainy: '/textures/grainy.jpg',
};
