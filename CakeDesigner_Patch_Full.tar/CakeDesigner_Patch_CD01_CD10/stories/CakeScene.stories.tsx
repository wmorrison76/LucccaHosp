import React from 'react';
import { CakeScene } from '../src/CakeScene';

export default {
  title: 'CakeDesigner/CakeScene',
  component: CakeScene,
};

export const Default = () => <CakeScene />;
