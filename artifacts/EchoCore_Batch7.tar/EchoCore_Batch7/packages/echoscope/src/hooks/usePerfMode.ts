// WB-04 PerfMode Detector
export function usePerfMode() {}
