// WB-01 FluidRoot store setup
export const windowManager = {};
