// CD-02 Material Manager
export const MaterialManager = {};
