// FG-03 Click-to-expand details
export default function FlagDetailPanel() {}
