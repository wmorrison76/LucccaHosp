// FG-02 Pre-built flags
export const PrebuiltFlags = {};
