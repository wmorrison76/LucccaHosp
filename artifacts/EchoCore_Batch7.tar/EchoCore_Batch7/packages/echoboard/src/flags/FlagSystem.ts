// FG-01 Flag system core
export const FlagSystem = {};
