// String Utilities
export function capitalize() {}
