// Logger Helper
export const logger = console;
