// Error Handler Helper
export function handleError() {}
