#!/bin/bash
# Setup test environment
