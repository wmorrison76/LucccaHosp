/**
 * PATCH v1 - DB-02: Enhanced Sidebar
 * Changes:
 * - Added custom width and background color props.
 * - Added smooth overlay transitions and ARIA attributes.
 */
import React, { useState } from 'react';
import { motion } from 'framer-motion';

const Sidebar = ({ children, width = 300, backgroundColor = 'rgba(255,255,255,0.7)' }) => {
  const [open, setOpen] = useState(true);
  return (
    <motion.div
      className="fixed top-0 left-0 h-full shadow-lg backdrop-blur-md z-50"
      style={{ width, backgroundColor }}
      initial={{ x: -width }}
      animate={{ x: open ? 0 : -width }}
      transition={{ type: 'tween', duration: 0.3 }}
      role="complementary"
      aria-hidden={!open}
    >
      <button onClick={() => setOpen(!open)} className="m-2 p-2 bg-gray-200 rounded">Toggle</button>
      {children}
    </motion.div>
  );
};

export default Sidebar;
