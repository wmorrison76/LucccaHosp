// Tests for QuickActionBar
