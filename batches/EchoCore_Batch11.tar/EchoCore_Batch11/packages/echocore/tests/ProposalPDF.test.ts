// Tests for ProposalPDF
