// Tests for BrandExtract
