// Tests for BEOGenerator
