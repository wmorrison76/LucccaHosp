// Tests for CommandRegistry
