// Tests for BrandApply
