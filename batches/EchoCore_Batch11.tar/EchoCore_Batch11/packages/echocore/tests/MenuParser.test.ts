// Tests for MenuParser
