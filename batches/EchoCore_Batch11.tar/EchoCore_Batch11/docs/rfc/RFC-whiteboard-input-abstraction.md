# RFC Whiteboard Input Abstraction
