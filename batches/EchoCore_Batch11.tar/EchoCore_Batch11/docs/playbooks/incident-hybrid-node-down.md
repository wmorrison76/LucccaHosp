# Playbook: Incident - Hybrid Node Down
