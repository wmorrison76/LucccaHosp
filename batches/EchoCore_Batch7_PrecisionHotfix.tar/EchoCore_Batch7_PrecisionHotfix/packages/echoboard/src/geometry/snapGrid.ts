/**
 * LUCCCA | SEG-A-WB-09
 * Precision Patch Applied: ε = 1e-5
 */
export const EPS = 1e-5;

export function preciseRound(value: number, places = 5): number {
  const p = Math.pow(10, places);
  return Math.round((value + Number.EPSILON) * p) / p;
}

export function approxEqual(a: number, b: number, eps = EPS): boolean {
  return Math.abs(a - b) <= eps;
}

export function snapGrid(value: number, step: number): number {
  if (step <= 0) return preciseRound(value, 5);
  const snapped = Math.round(value / step) * step;
  return preciseRound(snapped, 5);
}

export function snapPoint(x: number, y: number, step: number) {
  return { x: snapGrid(x, step), y: snapGrid(y, step) };
}

export function snapRect(rect: { x: number; y: number; w: number; h: number }, step: number) {
  return {
    x: snapGrid(rect.x, step),
    y: snapGrid(rect.y, step),
    w: snapGrid(rect.w, step),
    h: snapGrid(rect.h, step),
  };
}

export function rectHash(r: { x: number; y: number; w: number; h: number }): string {
  return [r.x, r.y, r.w, r.h].map(v => preciseRound(v, 5).toFixed(5)).join('|');
}
