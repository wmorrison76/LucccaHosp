/**
 * LUCCCA | SEG-A-WB-10
 * Precision Patch Applied: ε = 1e-5
 */
import { EPS, approxEqual } from './snapGrid';

export function detectCollision(a, b) {
  return !(
    a.x + a.w < b.x - EPS ||
    a.x - EPS > b.x + b.w ||
    a.y + a.h < b.y - EPS ||
    a.y - EPS > b.y + b.h
  );
}

export function resolveCollision(a, b) {
  const moveA = String(a.id) > String(b.id);
  const dxRight = (b.x + b.w) - a.x;
  const dxLeft = (a.x + a.w) - b.x;
  const dyDown = (b.y + b.h) - a.y;
  const dyUp = (a.y + a.h) - b.y;
  const minX = Math.min(dxRight, dxLeft);
  const minY = Math.min(dyDown, dyUp);

  if (minX < minY) {
    if (moveA) a.x += approxEqual(minX, 0) ? 0 : minX;
    else b.x -= approxEqual(minX, 0) ? 0 : minX;
  } else {
    if (moveA) a.y += approxEqual(minY, 0) ? 0 : minY;
    else b.y -= approxEqual(minY, 0) ? 0 : minY;
  }
  return { a, b };
}
