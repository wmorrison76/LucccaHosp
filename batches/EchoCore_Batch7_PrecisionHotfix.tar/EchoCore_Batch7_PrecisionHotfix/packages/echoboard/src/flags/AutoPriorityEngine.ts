/**
 * LUCCCA | FG-04 AutoPriority Engine
 * Deterministic Priority Normalization
 */
export function computePriority(flag) {
  const base = flag.severity === 'critical' ? 100 : 50;
  return parseFloat((base + flag.weight).toFixed(5));
}
