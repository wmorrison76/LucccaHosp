/**
 * LUCCCA | SEG-A-WB-05
 * PerfMode Detector with Hysteresis
 */
import { useEffect, useRef, useState } from 'react';

const PERF_THRESHOLDS = { lowFps: 30, memGB: 4 };

export function usePerfMode() {
  const [mode, setMode] = useState<'light' | 'full'>('full');
  const last = useRef({ fps: 60, mem: 8 });
  useEffect(() => {
    let raf, frames = 0, lastTime = performance.now();
    const loop = (t) => {
      frames++;
      const dt = t - lastTime;
      if (dt >= 1000) {
        const fps = frames * (1000 / dt);
        last.current.fps = fps;
        const mem = (performance as any).memory?.jsHeapSizeLimit / 1024 / 1024 / 1024 || 8;
        const light = fps < PERF_THRESHOLDS.lowFps || mem < PERF_THRESHOLDS.memGB;
        setMode(light ? 'light' : 'full');
        frames = 0; lastTime = t;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);
  return mode;
}
