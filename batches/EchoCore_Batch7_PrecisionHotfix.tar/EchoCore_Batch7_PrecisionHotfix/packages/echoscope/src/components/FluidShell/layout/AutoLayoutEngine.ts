/**
 * LUCCCA | SEG-A-WB-03
 * Deterministic AutoLayout Engine with Precision
 */
import { preciseRound } from '../../../../echoboard/src/geometry/snapGrid';

export function autoLayout(panes, viewport) {
  const cols = viewport.width > 1280 ? 12 : 4;
  const step = viewport.width / cols;
  let x = 0, y = 0, rowH = 0;
  const out = [];
  for (const p of panes.sort((a, b) => String(a.id).localeCompare(String(b.id)))) {
    const w = Math.min(cols, p.defaultCols || 4);
    const width = step * w;
    const height = p.defaultHeight || step * 3;
    if (x + width > viewport.width + 1e-5) {
      x = 0;
      y += rowH;
      rowH = 0;
    }
    out.push({ id: p.id, x: preciseRound(x, 5), y: preciseRound(y, 5), w: preciseRound(width, 5), h: preciseRound(height, 5) });
    x += width;
    rowH = Math.max(rowH, height);
  }
  return out;
}
