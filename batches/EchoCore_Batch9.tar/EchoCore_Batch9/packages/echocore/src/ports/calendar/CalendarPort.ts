// AC-01 Calendar Port Interface
export interface CalendarPort {}
