// EA-04 Avatar Telemetry Emitter
export class AvatarTelemetryEmitter {}
