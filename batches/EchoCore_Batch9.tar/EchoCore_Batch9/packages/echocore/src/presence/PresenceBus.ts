// EA-01 Presence Bus
export class PresenceBus {}
