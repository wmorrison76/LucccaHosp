// AC-02 Google Calendar Adapter
export class GoogleCalendarAdapter {}
