# RFC Cake Designer Costing & Rendering

Placeholder documentation.
