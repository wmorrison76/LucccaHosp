// WB-12 Docking Hook
export function useDocking() {}
