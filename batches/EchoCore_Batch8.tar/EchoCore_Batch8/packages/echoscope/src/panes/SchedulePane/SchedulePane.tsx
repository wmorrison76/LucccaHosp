// Placeholder for future SchedulePane
export default function SchedulePane() {}
