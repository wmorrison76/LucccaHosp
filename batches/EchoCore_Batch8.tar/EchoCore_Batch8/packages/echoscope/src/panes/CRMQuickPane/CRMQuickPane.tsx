// Placeholder for CRMQuickPane
export default function CRMQuickPane() {}
