// WB-08 Global Shortcut Map
export const shortcutMap = {};
