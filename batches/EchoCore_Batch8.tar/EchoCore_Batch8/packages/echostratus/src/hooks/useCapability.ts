// FF-02 Capability Hook
export function useCapability() {}
