// FF-01 Capability Matrix
export const capabilities = {};
