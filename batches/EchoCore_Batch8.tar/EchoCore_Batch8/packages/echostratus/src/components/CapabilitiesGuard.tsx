// FF-03 Capabilities Guard
export default function CapabilitiesGuard() {}
