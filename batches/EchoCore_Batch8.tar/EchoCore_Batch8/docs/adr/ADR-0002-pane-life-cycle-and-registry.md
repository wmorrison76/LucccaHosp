# ADR-0002 Pane Life Cycle and Registry

Documentation placeholder.
