# ADR-0001 Fluid Whiteboard Shell

Documentation placeholder.
