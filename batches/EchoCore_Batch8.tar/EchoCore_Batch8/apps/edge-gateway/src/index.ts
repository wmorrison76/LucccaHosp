// AN-01 Edge Gateway Service
export function startEdgeGateway() {}
