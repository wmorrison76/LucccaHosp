// RBAC Permission Matrix
export const PermissionMatrix = {};
