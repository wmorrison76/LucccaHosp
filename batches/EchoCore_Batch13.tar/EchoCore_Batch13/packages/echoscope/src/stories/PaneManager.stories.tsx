// Storybook: PaneManager
