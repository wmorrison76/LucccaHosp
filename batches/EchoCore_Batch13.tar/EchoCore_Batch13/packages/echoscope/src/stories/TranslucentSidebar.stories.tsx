// Storybook: TranslucentSidebar
