// Fixture: Cake Design
