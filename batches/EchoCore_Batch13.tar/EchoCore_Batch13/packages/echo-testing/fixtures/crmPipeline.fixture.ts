// Fixture: CRM Pipeline
