// Fixture: Event Builder
