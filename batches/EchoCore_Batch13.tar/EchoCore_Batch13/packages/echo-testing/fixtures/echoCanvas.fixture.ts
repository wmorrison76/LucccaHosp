// Fixture: Echo Canvas
