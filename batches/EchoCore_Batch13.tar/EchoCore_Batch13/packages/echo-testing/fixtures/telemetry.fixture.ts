// Fixture: Telemetry Events
