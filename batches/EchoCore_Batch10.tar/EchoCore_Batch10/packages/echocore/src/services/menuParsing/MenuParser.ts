// EB-02 Menu Parser Service
export class MenuParser {}
