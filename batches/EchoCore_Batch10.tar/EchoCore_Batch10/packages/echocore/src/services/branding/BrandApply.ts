// MB-03 Brand Apply Service
export class BrandApply {}
