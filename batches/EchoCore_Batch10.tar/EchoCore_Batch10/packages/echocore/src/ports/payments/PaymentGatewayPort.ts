// CRM-04 Payment Gateway Port
export interface PaymentGatewayPort {}
