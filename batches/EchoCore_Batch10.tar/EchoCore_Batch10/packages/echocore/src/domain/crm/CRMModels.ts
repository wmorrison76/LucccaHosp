// CRM-01 CRM Models
export interface CRMModels {}
