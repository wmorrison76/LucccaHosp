// OT-02 Typed Domain Events Registry
export const domainEvents = {};
