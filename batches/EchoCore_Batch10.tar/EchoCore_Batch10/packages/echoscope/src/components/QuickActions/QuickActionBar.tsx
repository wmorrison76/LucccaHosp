// CP-03 Quick Action Bar
export default function QuickActionBar() {}
