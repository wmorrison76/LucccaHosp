// EB-01 Event Builder Pane
export default function EventBuilderPane() {}
