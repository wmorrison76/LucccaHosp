// CRM-02 CRM Pipeline Pane
export default function CRMPipelinePane() {}
