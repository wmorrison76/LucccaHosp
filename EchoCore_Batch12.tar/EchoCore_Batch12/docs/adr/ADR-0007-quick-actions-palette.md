# ADR-0007 Quick Actions Palette
