# ADR-0005 Telemetry & Presence
