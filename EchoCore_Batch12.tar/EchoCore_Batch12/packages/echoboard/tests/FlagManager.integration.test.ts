// Integration test for FlagManager
