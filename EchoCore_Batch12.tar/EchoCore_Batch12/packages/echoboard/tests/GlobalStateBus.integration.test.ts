// Integration test for GlobalStateBus
