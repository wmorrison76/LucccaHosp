// Integration test for CakeDesignerPane
