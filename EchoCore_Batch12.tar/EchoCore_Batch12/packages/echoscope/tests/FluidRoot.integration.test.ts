// Integration test for FluidRoot
