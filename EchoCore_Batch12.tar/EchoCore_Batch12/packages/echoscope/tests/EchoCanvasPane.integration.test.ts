// Integration test for EchoCanvasPane
