// Integration test for TelemetryConsole
