// Integration test for PaneManager
