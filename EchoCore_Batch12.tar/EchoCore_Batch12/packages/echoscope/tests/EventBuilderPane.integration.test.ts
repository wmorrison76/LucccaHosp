// Integration test for EventBuilderPane
