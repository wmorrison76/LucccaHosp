// Integration test for CRMPipelinePane
