// Integration test for AutoLayoutEngine
