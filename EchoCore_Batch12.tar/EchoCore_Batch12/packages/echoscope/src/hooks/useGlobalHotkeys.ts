// Hook: Global Hotkeys
export function useGlobalHotkeys() {}
