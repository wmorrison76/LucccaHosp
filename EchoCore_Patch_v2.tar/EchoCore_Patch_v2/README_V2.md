# EchoCore Patch V2

This directory contains Patch V2 components.