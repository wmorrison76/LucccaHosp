import React, { useState } from 'react';
import { motion } from 'framer-motion';

export const PaneManager = () => {
  const [panes, setPanes] = useState([{ id: 'pane-1', x: 50, y: 50 }]);
  return (
    <div className="absolute inset-0">
      {panes.map((pane) => (
        <motion.div
          key={pane.id}
          drag
          className="absolute bg-white dark:bg-gray-800 shadow-lg rounded-lg w-64 h-40 p-2"
          style={{ top: pane.y, left: pane.x }}
        >
          <span>{pane.id}</span>
        </motion.div>
      ))}
    </div>
  );
};