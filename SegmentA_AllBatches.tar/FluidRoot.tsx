import React, { useEffect } from 'react';
import { PaneManager } from './PaneManager';
import { usePerfMode } from '../hooks/usePerfMode';

export const FluidRoot = () => {
  const { perfMode } = usePerfMode();
  useEffect(() => {
    console.log(`FluidRoot initialized with perfMode: ${perfMode}`);
  }, [perfMode]);
  return (
    <main role="main" className="relative w-full h-full overflow-hidden bg-gray-50 dark:bg-gray-900">
      <PaneManager />
    </main>
  );
};