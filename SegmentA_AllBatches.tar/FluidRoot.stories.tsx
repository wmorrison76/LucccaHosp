export default {
  title: 'Whiteboard/FluidRoot',
  component: FluidRoot,
};

export const Default = () => <FluidRoot />;